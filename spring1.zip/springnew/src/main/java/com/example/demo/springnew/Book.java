package com.example.demo.springnew;

import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

//public class Book {
//  public class Book implements InitializingBean ,DisposableBean{
    
public class Book{
	int bookcode;
	String name;
	int price;
	
	List <String> cityList;
	Map<String,Double> sales;
	
	Book()
	{
		
	}

//	public Book(int bookcode, String name, int price) {
//		super();
//		this.bookcode = bookcode;
//		this.name = name;
//		this.price = price;
//	}

 
    public Book(int bookcode, String name, int price, List<String> cityList, Map<String, Double> sales) {
	super();
	this.bookcode = bookcode;
	this.name = name;
	this.price = price;
	this.cityList = cityList;
	this.sales = sales;
   }

    public List<String> getCityList() {
      return cityList;
    }

    public void setCityList(List<String> cityList) {
	  this.cityList = cityList;
    }

    
    
	public Map<String, Double> getSales() {
		return sales;
	}

	public void setSales(Map<String, Double> sales) {
		this.sales = sales;
	}

	
	public int getBookcode() {
    	  return bookcode;
     }
      
	public void setBookcode(int bookcode) {
		this.bookcode = bookcode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Book [bookcode=" + bookcode + ", name=" + name + ", price=" + price + ", cityList=" + cityList
				+ ", sales=" + sales + "]";
	}

//	@Override
//	public String toString() {
//		return "Book [bookcode=" + bookcode + ", name=" + name + ", price=" + price + "]";
//	}
//	
	
	
	
//	1. void m1()
//	{
//		
//		System.out.println("Starting .....");
//	}
//	
//	void m2()
//	{
//		
//		System.out.println("Ending  .....");
//	}
//	
	
	
//	2. public void afterPropertiesSet() throws Exception {
//			
//		System.out.println("starting ");
//			
//		}
//	 
//	    public void destroy() throws Exception {
//			System.out.println("Ending  ");
//			
//		}
	
//	3.@PostConstruct
//	void start()
//	{
//		System.out.println("starting ...");
//	}
//		
//	@PreDestroy
//	void stop()
//	{
//		System.out.println("ending  ...");
//	}
	
	
	
	
}

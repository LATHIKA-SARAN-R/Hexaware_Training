package com.hexa.hibernate.com.hexa.hibernateEX;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App {

    private static SessionFactory sessionFactory;

    public static void main(String[] args) {
      
        sessionFactory = new Configuration()
                .configure("hiber.config.xml")
                .buildSessionFactory();

      
        insertStudent(101, "Ajay", 1000.0);

      
        search(101);  
        search(999);   

  
        sessionFactory.close();
    }

 
    public static void insertStudent(int rollNo, String name, double marks) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Student student = new Student();
        student.setRollno(rollNo);
        student.setName(name);
        student.setMarks(marks);

        session.save(student);
        tx.commit();
        session.close();

        System.out.println("Student inserted successfully!");
    }


    public static void search(int rollNo) {
        Session session = sessionFactory.openSession();
        Student student = session.get(Student.class, rollNo);

        if (student != null) {
            System.out.println("Student Found: " + student.toString());
        } else {
            System.out.println("Student with Roll No " + rollNo + " not found.");
        }

        session.close();
    }

    public static void removeByRollNo(int rno) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        Student student = session.find(Student.class, rno);

        if (student == null) {
            System.out.println("Student with Roll No " + rno + " not found. Cannot delete.");
        } else {
            session.delete(student);
            System.out.println("Student with Roll No " + rno + " deleted successfully.");
        }

        tx.commit();
        session.close();
    }
    public static void updateNameFee(int roll, double marks, String name) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

     
        Student existingStudent = session.get(Student.class, roll);

        if (existingStudent != null) {
           
            existingStudent.setName(name);
            existingStudent.setMarks(marks);
            session.update(existingStudent);
            System.out.println("Student with Roll No " + roll + " updated successfully.");
        } else {
            
            System.out.println("Student with Roll No " + roll + " not found. Update aborted.");
        }

        tx.commit();
        session.close();
    }


   
 
}

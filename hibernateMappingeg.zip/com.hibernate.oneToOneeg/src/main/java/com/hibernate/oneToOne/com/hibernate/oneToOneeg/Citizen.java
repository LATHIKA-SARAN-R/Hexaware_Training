package com.hibernate.oneToOne.com.hibernate.oneToOneeg;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.JoinColumn;

@Entity
public class Citizen {

    @Id
    private int citizenId;
    private String name;

    @OneToOne
    @JoinColumn(name = "passport_id")
    private Passport passport;

    public Citizen() {}

    public Citizen(int citizenId, String name, Passport passport) {
        this.citizenId = citizenId;
        this.name = name;
        this.passport = passport;
    }

    public int getCitizenId() {
        return citizenId;
    }

    public void setCitizenId(int citizenId) {
        this.citizenId = citizenId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Passport getPassport() {
        return passport;
    }

    public void setPassport(Passport passport) {
        this.passport = passport;
    }

    @Override
    public String toString() {
        return "Citizen [citizenId=" + citizenId + ", name=" + name + ", passport=" + passport + "]";
    }
}

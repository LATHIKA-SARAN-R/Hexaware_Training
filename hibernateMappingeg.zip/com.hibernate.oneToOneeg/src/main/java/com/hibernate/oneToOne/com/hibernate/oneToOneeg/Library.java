package com.hibernate.oneToOne.com.hibernate.oneToOneeg;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.CascadeType;

@Entity
public class Library {

    @Id
    private int libId;
    private String libName;

    @OneToMany(targetEntity = Book.class, cascade = CascadeType.ALL)
    private List<Book> books;

    public Library() {
    }

    public Library(int libId, String libName, List<Book> books) {
        this.libId = libId;
        this.libName = libName;
        this.books = books;
    }

    public int getLibId() {
        return libId;
    }

    public void setLibId(int libId) {
        this.libId = libId;
    }

    public String getLibName() {
        return libName;
    }

    public void setLibName(String libName) {
        this.libName = libName;
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    @Override
    public String toString() {
        return "Library [libId=" + libId + ", libName=" + libName + ", books=" + books + "]";
    }
}

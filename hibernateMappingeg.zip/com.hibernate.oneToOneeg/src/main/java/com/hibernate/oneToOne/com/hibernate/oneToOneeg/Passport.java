package com.hibernate.oneToOne.com.hibernate.oneToOneeg;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Passport {

    @Id
    private int passportNumber;
    private String country;

    public Passport() {}

    public Passport(int passportNumber, String country) {
        this.passportNumber = passportNumber;
        this.country = country;
    }

    public int getPassportNumber() {
        return passportNumber;
    }

    public void setPassportNumber(int passportNumber) {
        this.passportNumber = passportNumber;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    @Override
    public String toString() {
        return "Passport [passportNumber=" + passportNumber + ", country=" + country + "]";
    }
}

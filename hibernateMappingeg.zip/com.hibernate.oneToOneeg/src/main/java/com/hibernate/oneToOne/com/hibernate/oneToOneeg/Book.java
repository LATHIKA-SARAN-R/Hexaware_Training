package com.hibernate.oneToOne.com.hibernate.oneToOneeg;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Book {

    @Id
    private int bookId;
    private String title;

    public Book() {
    }

    public Book(int bookId, String title) {
        this.bookId = bookId;
        this.title = title;
    }

   
    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return "Book [bookId=" + bookId + ", title=" + title + "]";
    }
}

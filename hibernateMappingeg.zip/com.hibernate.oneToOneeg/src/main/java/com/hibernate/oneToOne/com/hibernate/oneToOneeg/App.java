package com.hibernate.oneToOne.com.hibernate.oneToOneeg;

import java.util.List;
import java.util.ArrayList;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 
 
 
 
 
/**
* Hello world!
*
*/
public class App
{
    public static void main( String[] args )
    {
   SessionFactory sessionFactory= new Configuration().
		   configure("hiber.config.xml").
		   addAnnotatedClass(Student.class).
		   addAnnotatedClass(Address.class).
		   buildSessionFactory();
   
      
          Session session =sessionFactory.openSession();
          
          Transaction txt =session.beginTransaction();
          
          Department d =session.get(Department.class,1);
          System.out.print(d.getdName());
          System.out.print(d.getEmplist());
          
          
          
          
         /* Address a1= new Address();
          a1.setAddressid(1);
          a1.setCity("bombay");
          
          session.save(a1);
          
          Student s1 = new Student();
          s1.setRollno(101);
          s1.setName("Ajay");
          s1.setAddress(a1);
          
          
          
          session.save(s1);
          txt.commit();
          
      
          Passport passport = new Passport(1111, "India");
          Citizen citizen = new Citizen(1, "Rahul", passport);

          session.save(passport); 
          session.save(citizen);  */
          
        
          
          Employee e1= new Employee(101,"asha",3000.0);
          Employee e2= new Employee(102,"jay",7000.0);

         
         List<Employee> list= new ArrayList();
         list.add(e1);
         list.add(e2);

         Department ojbD= new Department();
         ojbD.setdCode(1);
         ojbD.setdName("Admin");
         ojbD.setEmplist(list);

         session.save(ojbD);
         txt.commit(); 
          
          
          /*Book b1 = new Book(1, "Core Java");
          Book b2 = new Book(2, "Hibernate Basics");
          Book b3 = new Book(3, "Spring Boot");

          List<Book> bookList = new ArrayList();
          bookList.add(b1);
          bookList.add(b2);
          bookList.add(b3);

          Library library = new Library();
          library.setLibId(101);
          library.setLibName("City Central Library");
          library.setBooks(bookList);

          session.save(library);*/



          
          

          
          
          
   
   
   
   
   
   
   
 
    }
}

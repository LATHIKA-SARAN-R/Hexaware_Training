package com.example.demo.spring2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
        	ApplicationContext con= new AnnotationConfigApplicationContext(StudentConfig.class);
        	
        	Student s=(Student)con.getBean("s1");
            System.out.print(s.toString() );
//            
//            Student s2=(Student)con.getBean("s2");
//            System.out.print(s2.toString() );
            
            College c1=(College)con.getBean("c1");
            System.out.println(c1.toString() );
        
        
    }
     
    
}

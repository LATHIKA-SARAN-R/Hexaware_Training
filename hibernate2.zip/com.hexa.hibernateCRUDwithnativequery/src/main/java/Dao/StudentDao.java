package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import java.util.List;

import Connection.StudentConn;
import Model.Student;

public class StudentDao implements DaoStudentl {

    public void saveData(Student student) {
        Session session = StudentConn.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        session.save(student);
        transaction.commit();
        session.close();

        System.out.println("Student saved successfully!");
    }

    public void updateData(Student student) {
        Session session = StudentConn.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        session.update(student);
        transaction.commit();
        session.close();

        System.out.println("Student updated successfully.");
    }

    public void deleteData(int rollNo) {
        Session session = StudentConn.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        String sql = "DELETE FROM students WHERE roll_no = :rollNo";
        NativeQuery<?> query = session.createNativeQuery(sql);
        query.setParameter("rollNo", rollNo);

        int rowsAffected = query.executeUpdate();
        transaction.commit();
        session.close();

        if (rowsAffected > 0) {
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found with roll number: " + rollNo);
        }
    }

    public List<Student> searchByName(String name) {
        Session session = StudentConn.getSessionFactory().openSession();

        Query<Student> query = session.createQuery("FROM Student WHERE name = :name", Student.class);
        query.setParameter("name", name);

        List<Student> resultList = query.list();
        session.close();

        return resultList;
    }

    public List<Student> getAllStudents() {
        Session session = StudentConn.getSessionFactory().openSession();

        Query<Student> query = session.createQuery("FROM Student", Student.class);
        List<Student> list = query.list();

        session.close();
        return list;
    }

    public void updateStudentNameByRoll(int rollNo, String name) {
        Session session = StudentConn.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        String sql = "UPDATE students SET name = :name WHERE roll_no = :rollNo";
        NativeQuery<?> query = session.createNativeQuery(sql);
        query.setParameter("name", name);
        query.setParameter("rollNo", rollNo);

        int rowsAffected = query.executeUpdate();
        transaction.commit();
        session.close();

        if (rowsAffected > 0) {
            System.out.println("Student name updated successfully.");
        } else {
            System.out.println("No student found with roll number: " + rollNo);
        }
    }
}


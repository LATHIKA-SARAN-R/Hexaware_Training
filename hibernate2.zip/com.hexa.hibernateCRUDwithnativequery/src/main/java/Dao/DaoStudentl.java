package Dao;

import Model.Student;
import java.util.List;

public interface DaoStudentl {
    void saveData(Student s);
    void updateData(Student s);
    void deleteData(int rollNo);
    List<Student> searchByName(String name);
    List<Student> getAllStudents();
    void updateStudentNameByRoll(int rollNo, String name);


}

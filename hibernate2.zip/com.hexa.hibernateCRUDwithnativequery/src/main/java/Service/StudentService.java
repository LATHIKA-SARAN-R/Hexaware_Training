package Service;

import java.util.Scanner;
import java.util.List;

import Dao.StudentDao;
import Model.Student;

public class StudentService {
    Student s;
    StudentDao dao;
    Scanner sc;

    public StudentService() {
        s = new Student();
        sc = new Scanner(System.in);
        dao = new StudentDao();
    }

    public void saveStudent() {
        System.out.println("Enter roll number: ");
        s.setRollno(sc.nextInt());
        sc.nextLine(); 

        System.out.println("Enter name: ");
        s.setName(sc.nextLine());

        System.out.println("Enter marks: ");
        s.setMarks(sc.nextDouble());

        dao.saveData(s);
    }
    
    public void updateStudent() {
        System.out.println("Enter roll number to update:");
        int rollNo = sc.nextInt();
        sc.nextLine(); 

        System.out.println("Enter new name:");
        String name = sc.nextLine();

        System.out.println("Enter new marks:");
        double marks = sc.nextDouble();

        Student s = new Student(rollNo, name, marks);
        dao.updateData(s);
    }

    public void deleteStudent() {
        System.out.println("Enter roll number to delete:");
        int rollNo = sc.nextInt();
        dao.deleteData(rollNo);
    }
    
    public void searchByName() {
        System.out.println("Enter name to search:");
        String name = sc.nextLine();  
        if (name.isEmpty()) name = sc.nextLine(); 

        List<Student> students = dao.searchByName(name);
        if (students != null && !students.isEmpty()) {
            System.out.println("Matching students:");
            for (Student s : students) {
                System.out.println(s.toString());
            }
        } else {
            System.out.println("No student found with name: " + name);
        }
    }
    
    
    
    public void getAllStudents() {
        List<Student> students = dao.getAllStudents();

        if (students != null && !students.isEmpty()) {
            System.out.println("All Students:");
            for (Student s : students) {
                System.out.println(s.toString());
            }
        } else {
            System.out.println("No student records found.");
        }
    }
    
    public void updateStudentNameByRoll() {
        System.out.print("Enter roll number: ");
        int roll = sc.nextInt();
        sc.nextLine(); 

        System.out.print("Enter new name: ");
        String name = sc.nextLine();

        dao.updateStudentNameByRoll(roll, name);
    }



   

}

package com.hexa.hibernateMVC.com.hexa.hibernateMVC1;

import Service.StudentService;

public class App {
    public static void main(String[] args) {
        StudentService service = new StudentService();

        
        service.saveStudent();
        service.updateStudent();
        service.deleteStudent();
    }
}


package Dao;

import Model.Student;

public interface DaoStudentl {
    void saveData(Student s);
    void updateData(Student s);
    void deleteData(int rollNo);
}

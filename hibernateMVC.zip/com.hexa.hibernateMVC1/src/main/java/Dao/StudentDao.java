ppackage Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import Connection.StudentConn;
import Model.Student;

public class StudentDao implements DaoStudentl {

    public void saveData(Student student) {
        Session session = StudentConn.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        session.save(student);
        transaction.commit();
        session.close();

        System.out.println("Student saved successfully!");
    }

    public void updateData(Student student) {
        Session session = StudentConn.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        session.update(student);
        transaction.commit();
        session.close();

        System.out.println("Student updated successfully.");
    }

    public void deleteData(int rollNo) {
        Session session = StudentConn.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        Student student = session.get(Student.class, rollNo);
        if (student != null) {
            session.delete(student);
            transaction.commit();
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found with roll number: " + rollNo);
            transaction.rollback();
        }

        session.close();
    }
}
